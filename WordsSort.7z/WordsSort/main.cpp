#include <QCoreApplication>
#include <iostream>
#include <string>
#include "letterssort.h"
#include "gtest/gtest.h"

TEST(test001, test)
{
    std::string const letters = "A B C R K H H F D I E F G B N T O H G H F J K L F D";
    LettersSort lettersSort = LettersSort(letters);
    std::string sortedLetters = lettersSort.getletters();

    std::string expected = "A B B C D D E F F F F G G H H H H I J K K L N O R T";

    ASSERT_EQ(sortedLetters, expected);
}

TEST(test002, test)
{
    std::string const letters = "";
    LettersSort lettersSort = LettersSort(letters);
    std::string sortedLetters = lettersSort.getletters();

    std::string expected = "";

    ASSERT_EQ(sortedLetters, expected);
}

TEST(test003, test)
{
    std::string const letters = "T";
    LettersSort lettersSort = LettersSort(letters);
    std::string sortedLetters = lettersSort.getletters();

    std::string expected = "T";

    ASSERT_EQ(sortedLetters, expected);
}

TEST(test004, test)
{
    std::string const letters = "a A";
    LettersSort lettersSort = LettersSort(letters);
    std::string sortedLetters = lettersSort.getletters();

    std::string expected = "A a";

    ASSERT_EQ(sortedLetters, expected);
}


int main(int argc, char *argv[])
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
